Дивись README.md для інструкцій!
Пакет: com.systemupdate.app | Версія: 1.0.0